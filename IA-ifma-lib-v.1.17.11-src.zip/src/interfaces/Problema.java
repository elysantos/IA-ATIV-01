/*
 * Projeto: Exemplos de implementacao para disciplina 
 * Inteligencia Artificial do curso de SI (IFMA/Monte Castelo)
 *
 * Copyright 2015 by Josenildo Silva <jcsilva@ifma.edu.br>
 */

package interfaces;

import java.util.Set;

/**
 * Representa uma instancia de um problema formal.
 * @author Josenildo Silva <jcsilva@ifma.edu.br>
 */
public interface Problema {
    public Estado resultado(Acao a, Estado e);
    public Set<Acao> acoes(Estado e);
    public Set<java.util.Map.Entry<Acao,Estado>> sucessores(Estado e);
    public boolean testaObjetivo(Estado e);

    /**
     * Informa o custo da ação a quando em um estado ei indo para estado ej.
     * @param a ação 
     * @param ei estado onde a acao foi aplicada
     * @param ej estado resultante da aplicação da acao
     * @return custo da aplicação da ação no estado ei
     */
    public double custo(Acao a, Estado ei);
    
    public Estado estadoInicial();
}
